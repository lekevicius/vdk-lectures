$(function() {
  // Vieta jusu JavaScript
});
